<?php

declare(strict_types=1);

namespace App\Support\Supabase\Contracts;

use App\Support\Supabase\Exceptions\SupabaseAuthException;

/**
 * Writes course catalogue / marketing / commercial fields — the "shop window"
 * columns on the `courses` table that the course editor manages (migration 007
 * plus the base fields from 001/003).
 *
 * Writes use the server-side service-role key and are only reached on the
 * owner-gated platform routes; the route middleware is the authorisation
 * boundary (Supabase RLS — can_manage_course — still protects direct client
 * access). Versioned content copy (description/aims on course_versions) and the
 * content tree are separate writers in later slices.
 */
interface WritesCourses
{
    /**
     * Patch the given course's editable fields. Only the provided keys are
     * written; `updated_at` is stamped by the implementation.
     *
     * @param  array<string,mixed>  $fields
     *
     * @throws SupabaseAuthException
     */
    public function updateDetails(string $courseId, array $fields): void;
}
