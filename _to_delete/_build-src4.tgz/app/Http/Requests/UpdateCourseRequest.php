<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Auth\SupabaseUser;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Validates a course-details save from the Global Courses editor.
 *
 * Covers the catalogue / marketing / commercial fields on the `courses` table
 * (migration 007 + base). Authoring is owner-gated at the route; this Request
 * is the field-level guard. Content copy and the content tree are separate.
 */
final class UpdateCourseRequest extends FormRequest
{
    public function authorize(): bool
    {
        $user = $this->user();

        return $user instanceof SupabaseUser && $user->isPlatformOwner();
    }

    /**
     * @return array<string,mixed>
     */
    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:200'],
            'category_id' => ['nullable', 'uuid'],
            'content_type' => ['required', Rule::in(['native', 'scorm', 'mixed'])],
            'catalog_status' => ['required', Rule::in(['published', 'coming_soon', 'retired'])],
            'level' => ['nullable', 'string', 'max:60'],
            'duration_min' => ['nullable', 'integer', 'min:0', 'max:100000'],
            'description' => ['nullable', 'string', 'max:5000'],
            'accreditation' => ['nullable', 'string', 'max:200'],
            'cpd_points' => ['nullable', 'numeric', 'min:0', 'max:1000'],
            'cpd_body' => ['nullable', 'string', 'max:200'],
            'issues_certificate' => ['sometimes', 'boolean'],
            'certificate_validity_months' => ['nullable', 'integer', 'min:0', 'max:600'],
            'hero_image_path' => ['nullable', 'string', 'max:500'],
            'hero_image_alt' => ['nullable', 'string', 'max:300'],
            'meta_title' => ['nullable', 'string', 'max:200'],
            'meta_description' => ['nullable', 'string', 'max:500'],
        ];
    }

    /**
     * @return array<string,string>
     */
    public function attributes(): array
    {
        return [
            'category_id' => 'category',
            'duration_min' => 'duration',
            'cpd_points' => 'CPD points',
            'cpd_body' => 'CPD body',
            'certificate_validity_months' => 'certificate validity',
            'hero_image_alt' => 'hero image alt text',
        ];
    }
}
