<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Auth\SupabaseUser;
use App\Http\Requests\UpdateCourseRequest;
use App\Support\Supabase\Contracts\WritesCourses;
use App\Support\Supabase\Exceptions\SupabaseAuthException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\View\View;

/**
 * The course "details" editor — catalogue, media, SEO and certification fields
 * on the course itself (migration 007). Owner-gated by the `platform.owner`
 * middleware; writes go through {@see WritesCourses} (service-role), with
 * Supabase RLS as defence-in-depth.
 *
 * Version content/copy, pricing, territories and authors are separate editor
 * slices; this covers the course-level catalogue/commercial settings.
 */
final class CourseEditorController extends Controller
{
    public function edit(Request $request, string $course): View
    {
        /** @var SupabaseUser $user */
        $user = $request->user();

        $row = $this->loadCourse($course);
        if ($row === null) {
            abort(404);
        }

        return view('platform.courses.edit', [
            'user' => $user,
            'course' => $row,
            'categoryOptions' => $this->categoryOptions(),
            'statusOptions' => [
                ['value' => 'published', 'label' => 'Published'],
                ['value' => 'coming_soon', 'label' => 'Coming soon'],
                ['value' => 'retired', 'label' => 'Retired'],
            ],
            'typeOptions' => [
                ['value' => 'native', 'label' => 'Native'],
                ['value' => 'scorm', 'label' => 'SCORM'],
                ['value' => 'mixed', 'label' => 'Mixed'],
            ],
        ]);
    }

    public function update(UpdateCourseRequest $request, WritesCourses $writer, string $course): RedirectResponse
    {
        try {
            $writer->updateCourse($course, $request->courseFields());
        } catch (SupabaseAuthException $e) {
            report($e);

            return redirect()->route('platform.courses.edit', $course)
                ->withInput()
                ->with('editorError', 'The course could not be saved right now. Please try again shortly.');
        }

        return redirect()->route('platform.courses.show', $course)
            ->with('status', 'Course details saved.');
    }

    /**
     * Full course row (all columns) so the form can pre-fill the 007 fields.
     *
     * @return array<string,mixed>|null
     */
    private function loadCourse(string $courseId): ?array
    {
        try {
            $response = $this->req()->get('/rest/v1/courses', [
                'select' => '*',
                'id' => 'eq.'.$courseId,
            ]);
        } catch (\Throwable) {
            abort(503, 'The course could not be loaded right now. Please try again shortly.');
        }

        if (! $response->successful()) {
            abort(503, 'The course could not be loaded right now. Please try again shortly.');
        }

        /** @var array<int,array<string,mixed>> $rows */
        $rows = $response->json() ?? [];

        return $rows[0] ?? null;
    }

    /**
     * @return array<int,array{value:string,label:string}>
     */
    private function categoryOptions(): array
    {
        try {
            $response = $this->req()->get('/rest/v1/course_categories', [
                'select' => 'id,name', 'order' => 'name.asc',
            ]);
            if (! $response->successful()) {
                return [];
            }
            $rows = $response->json() ?? [];
        } catch (\Throwable) {
            return [];
        }

        $out = [];
        foreach ($rows as $r) {
            $id = (string) ($r['id'] ?? '');
            if ($id !== '') {
                $out[] = ['value' => $id, 'label' => (string) ($r['name'] ?? '')];
            }
        }

        return $out;
    }

    private function req(): \Illuminate\Http\Client\PendingRequest
    {
        /** @var array<string,mixed> $config */
        $config = config('services.supabase', []);
        $key = (string) ($config['service_role_key'] ?? '');

        return Http::baseUrl((string) ($config['url'] ?? ''))
            ->timeout((int) ($config['timeout'] ?? 10))
            ->acceptJson()
            ->withHeaders(['apikey' => $key])
            ->withToken($key);
    }
}
