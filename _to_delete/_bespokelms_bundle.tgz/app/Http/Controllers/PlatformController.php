<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Auth\SupabaseUser;
use App\Support\Supabase\Contracts\ReadsOrganizations;
use App\Support\Supabase\Exceptions\SupabaseAuthException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * The BespokeLMS platform-owner console.
 *
 * Access is gated twice: the "platform.owner" route middleware (404s non-owners)
 * and Supabase RLS on every table the console reads with a user token. The
 * cross-tenant estate view is read with the service-role key (see
 * {@see ReadsOrganizations}); the route middleware is its authorisation boundary.
 *
 * Every tenant, and everything shown about it, is loaded from Supabase — the
 * platform is fully database-driven so new white-label tenants are pure
 * configuration, scaling to hundreds of organisations.
 */
final class PlatformController extends Controller
{
    /**
     * Tenants index — a flat, sortable/filterable table of every organisation
     * in the estate (operators and their client organisations).
     */
    public function index(Request $request, ReadsOrganizations $organizations): View
    {
        /** @var SupabaseUser $user */
        $user = $request->user();

        $q = trim((string) $request->query('q', ''));

        try {
            $rows = $organizations->all();
        } catch (SupabaseAuthException $e) {
            report($e);

            return view('platform.home', [
                'user' => $user,
                'tenants' => null,
                'summary' => null,
                'modelOptions' => [],
                'estateError' => 'The tenant list could not be loaded right now. Please try again shortly.',
                'q' => $q,
            ]);
        }

        [$tenants, $summary, $modelOptions] = $this->buildTenants($rows);

        return view('platform.home', [
            'user' => $user,
            'tenants' => $tenants,
            'summary' => $summary,
            'modelOptions' => $modelOptions,
            'estateError' => null,
            'q' => $q,
        ]);
    }

    /**
     * Per-tenant admin console — the configuration hub for one organisation's
     * white-label instance.
     */
    public function show(Request $request, ReadsOrganizations $organizations, string $tenant): View
    {
        /** @var SupabaseUser $user */
        $user = $request->user();

        try {
            $rows = $organizations->all();
        } catch (SupabaseAuthException $e) {
            report($e);
            abort(503, 'The tenant could not be loaded right now. Please try again shortly.');
        }

        $byId = [];
        foreach ($rows as $row) {
            $byId[(string) ($row['id'] ?? '')] = $row;
        }

        $row = $byId[$tenant] ?? null;
        if ($row === null) {
            abort(404);
        }

        [$tenants] = $this->buildTenants($rows);

        return view('platform.tenants.show', [
            'user' => $user,
            'tenant' => $this->buildTenantDetail($row, $byId, $rows),
            'tenants' => $tenants,
        ]);
    }

    /**
     * Shape the flat organisation rows into the table model, a summary, and the
     * distinct "model" options used by the table's filter.
     *
     * @param  array<int,array<string,mixed>>  $rows
     * @return array{0:array<int,array<string,mixed>>,1:array<string,int>,2:array<int,array{value:string,label:string}>}
     */
    private function buildTenants(array $rows): array
    {
        $nameById = [];
        $childCount = [];
        foreach ($rows as $row) {
            $nameById[(string) ($row['id'] ?? '')] = (string) ($row['name'] ?? '');
            $parentId = (string) ($row['parent_id'] ?? '');
            if ($parentId !== '') {
                $childCount[$parentId] = ($childCount[$parentId] ?? 0) + 1;
            }
        }

        $tenants = [];
        $operators = 0;
        $clients = 0;
        $userTotal = 0;
        $models = [];

        foreach ($rows as $row) {
            $type = (string) ($row['type'] ?? '');

            // The platform organisation itself is not a tenant in the table.
            if ($type === 'platform') {
                continue;
            }

            $id = (string) ($row['id'] ?? '');
            $users = (int) ($row['user_count'] ?? 0);
            $parentId = (string) ($row['parent_id'] ?? '');

            [$modelValue, $modelLabel] = $this->model($type, $row['operator_subtype'] ?? null, $row['subtype'] ?? null);
            if ($modelValue !== '') {
                $models[$modelValue] = $modelLabel;
            }

            if ($type === 'operator') {
                $operators++;
            } elseif ($type === 'client') {
                $clients++;
            }
            $userTotal += $users;

            $tenants[] = [
                'id' => $id,
                'name' => (string) ($row['name'] ?? ''),
                'slug' => (string) ($row['slug'] ?? ''),
                'type' => $type,
                'type_label' => $type === 'operator' ? 'Operator' : 'Client',
                'model_value' => $modelValue,
                'model_label' => $modelLabel,
                'parent_id' => $parentId !== '' ? $parentId : null,
                'parent_name' => $parentId !== '' ? ($nameById[$parentId] ?? null) : null,
                'location' => $row['location'] !== null ? (string) $row['location'] : null,
                'user_count' => $users,
                'client_count' => (int) ($childCount[$id] ?? 0),
                'created_sort' => (string) ($row['created_at'] ?? ''),
                'created_label' => $this->formatDate($row['created_at'] ?? null),
            ];
        }

        usort($tenants, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        ksort($models);
        $modelOptions = [];
        foreach ($models as $value => $label) {
            $modelOptions[] = ['value' => (string) $value, 'label' => (string) $label];
        }

        return [
            $tenants,
            [
                'operators' => $operators,
                'clients' => $clients,
                'users' => $userTotal,
                'tenants' => count($tenants),
            ],
            $modelOptions,
        ];
    }

    /**
     * Build the detail model for a single tenant's configuration hub.
     *
     * @param  array<string,mixed>  $row
     * @param  array<string,array<string,mixed>>  $byId
     * @param  array<int,array<string,mixed>>  $rows
     * @return array<string,mixed>
     */
    private function buildTenantDetail(array $row, array $byId, array $rows): array
    {
        $id = (string) ($row['id'] ?? '');
        $type = (string) ($row['type'] ?? '');
        [$modelValue, $modelLabel] = $this->model($type, $row['operator_subtype'] ?? null, $row['subtype'] ?? null);

        $parentId = (string) ($row['parent_id'] ?? '');
        $parent = null;
        if ($parentId !== '' && isset($byId[$parentId])) {
            $p = $byId[$parentId];
            $parent = [
                'id' => $parentId,
                'name' => (string) ($p['name'] ?? ''),
                'slug' => (string) ($p['slug'] ?? ''),
                'is_platform' => (string) ($p['type'] ?? '') === 'platform',
            ];
        }

        $children = [];
        foreach ($rows as $r) {
            if ((string) ($r['parent_id'] ?? '') !== $id) {
                continue;
            }
            [$cv, $cl] = $this->model((string) ($r['type'] ?? ''), $r['operator_subtype'] ?? null, $r['subtype'] ?? null);
            $children[] = [
                'id' => (string) ($r['id'] ?? ''),
                'name' => (string) ($r['name'] ?? ''),
                'model_label' => $cl,
                'location' => $r['location'] !== null ? (string) $r['location'] : null,
                'user_count' => (int) ($r['user_count'] ?? 0),
            ];
        }
        usort($children, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        $slug = (string) ($row['slug'] ?? '');
        $isOperator = $type === 'operator';
        $hasClientLayer = (bool) ($row['has_client_layer'] ?? false);

        return [
            'id' => $id,
            'name' => (string) ($row['name'] ?? ''),
            'type' => $type,
            'type_label' => $isOperator ? 'Operator' : 'Client',
            'model_value' => $modelValue,
            'model_label' => $modelLabel,
            'slug' => $slug,
            'location' => $row['location'] !== null ? (string) $row['location'] : null,
            'created_label' => $this->formatDate($row['created_at'] ?? null),
            'user_count' => (int) ($row['user_count'] ?? 0),
            'has_client_layer' => $hasClientLayer,
            'is_operator' => $isOperator,
            // Routing model (memory: operators on subdomains, clients path-based).
            'subdomain' => $isOperator && $slug !== '' ? $slug.'.bespokelms.com' : null,
            'workspace_path' => $slug !== '' ? '/'.$slug : null,
            'parent' => $parent,
            'clients' => $children,
            'client_count' => count($children),
            'brand_swatches' => $this->brandSwatches($row['brand_theme'] ?? null),
        ];
    }

    /**
     * Map an organisation's type + subtype to a filter value and display label.
     *
     * @return array{0:string,1:string}
     */
    private function model(string $type, mixed $operatorSubtype, mixed $subtype): array
    {
        $raw = $type === 'operator' ? (string) ($operatorSubtype ?? '') : (string) ($subtype ?? '');

        $label = match ($raw) {
            'reseller' => 'Reseller',
            'inhouse' => 'In-house',
            'own_brand' => 'Own brand',
            'school' => 'School',
            'trust' => 'Trust',
            'college' => 'College',
            'nursery' => 'Nursery',
            '' => '—',
            default => Str::of($raw)->replace('_', ' ')->title()->toString(),
        };

        return [$raw, $label];
    }

    /**
     * Extract hex-colour swatches from a tenant's brand_theme jsonb, whatever
     * its shape. Returns an empty array when no brand kit is configured.
     *
     * @return array<int,array{label:string,value:string}>
     */
    private function brandSwatches(mixed $brandTheme): array
    {
        if (! is_array($brandTheme)) {
            return [];
        }

        $swatches = [];
        $walk = function (array $node, string $prefix) use (&$walk, &$swatches): void {
            foreach ($node as $key => $value) {
                if (is_array($value)) {
                    $walk($value, $prefix === '' ? (string) $key : $prefix.' '.$key);
                    continue;
                }
                if (is_string($value) && preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', $value) === 1) {
                    $label = trim($prefix === '' ? (string) $key : $prefix.' '.$key);
                    $swatches[] = [
                        'label' => Str::of($label)->replace(['_', '-'], ' ')->title()->toString(),
                        'value' => $value,
                    ];
                }
            }
        };
        $walk($brandTheme, '');

        return array_slice($swatches, 0, 24);
    }

    private function formatDate(mixed $raw): string
    {
        if (! is_string($raw) || $raw === '') {
            return '—';
        }

        try {
            return Carbon::parse($raw)->format('j M Y');
        } catch (\Throwable) {
            return substr($raw, 0, 10);
        }
    }
}
