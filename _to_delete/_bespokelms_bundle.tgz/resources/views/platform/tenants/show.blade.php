@extends('layouts.app')

@section('title', $tenant['name'].' · Platform')

@section('content')
<div class="flex flex-col items-start gap-6 lg:flex-row lg:items-stretch lg:gap-8">
    <!-- Left rail -->
    <aside class="w-full lg:w-rail lg:flex-none">
        <x-workspace-switcher active="platform" />

        <div class="rounded-control bg-paper p-6">
            <div class="mb-5 border-b border-line pb-5">
                <a href="{{ route('platform.home') }}"
                   class="inline-flex items-center gap-1.5 text-xs font-semibold text-teachhq transition hover:text-teachhq-dark focus:outline-none focus-visible:ring-2 focus-visible:ring-teachhq focus-visible:ring-offset-2">
                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
                    All tenants
                </a>
                <p class="mt-3 text-xs font-bold uppercase tracking-wider text-teachhq">{{ $tenant['type_label'] }} tenant</p>
                <p class="mt-1 text-lg font-black text-slatecard">{{ $tenant['name'] }}</p>
                <p class="mt-1 text-caption text-ink-soft">/{{ $tenant['slug'] }}</p>
            </div>

            <nav aria-label="Tenant configuration sections">
                <div class="mb-2.5 text-xs font-bold uppercase tracking-wider text-teachhq">Configuration</div>
                <ul>
                    @php
                        $sections = [
                            ['id' => 'overview', 'label' => 'Overview'],
                            ['id' => 'branding', 'label' => 'Branding & brand kit'],
                            ['id' => 'domain', 'label' => 'Domain & routing'],
                            ['id' => 'clients', 'label' => $tenant['is_operator'] ? 'Client organisations' : 'Parent operator'],
                            ['id' => 'users', 'label' => 'Users & roles'],
                            ['id' => 'courses', 'label' => 'Courses'],
                            ['id' => 'ai', 'label' => 'AI & integrations'],
                        ];
                    @endphp
                    @foreach ($sections as $s)
                        <li>
                            <a href="#{{ $s['id'] }}"
                               class="flex items-center gap-2.5 border-b border-line py-2.5 text-sm font-medium text-slatecard transition hover:text-teachhq focus:outline-none focus-visible:ring-2 focus-visible:ring-teachhq focus-visible:ring-offset-2 {{ $loop->last ? 'border-b-0' : '' }}">
                                <span class="min-w-0 flex-1 truncate">{{ $s['label'] }}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main content -->
    <main class="min-w-0 flex-1">
        <!-- Header -->
        <div class="mb-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div class="min-w-0">
                <p class="text-xs font-bold uppercase tracking-wider text-teachhq">BespokeLMS &middot; Tenant configuration</p>
                <h1 class="mt-1 flex flex-wrap items-center gap-2.5 text-2xl font-black text-slatecard">
                    {{ $tenant['name'] }}
                    <span class="inline-flex items-center rounded-full px-2 py-0.5 text-micro font-bold {{ $tenant['is_operator'] ? 'bg-teachhq-soft text-teachhq-dark' : 'bg-line-soft text-ink-soft' }}">{{ $tenant['type_label'] }}</span>
                    @if ($tenant['model_label'] !== '—')
                        <span class="inline-flex items-center rounded-full border border-line bg-surface px-2 py-0.5 text-micro font-bold text-ink-muted">{{ $tenant['model_label'] }}</span>
                    @endif
                </h1>
                <p class="mt-2 text-sm text-ink-soft">Configure this tenant's white-label LMS instance. All values are read from Supabase.</p>
            </div>
            <div class="flex flex-col gap-3 sm:flex-row sm:items-center lg:flex-none">
                <x-tenant-selector :tenants="$tenants" :current="$tenant['id']" label="Switch tenant" id="switch-tenant" />
                <button type="button" disabled
                        class="inline-flex items-center justify-center gap-1.5 rounded-control border border-teachhq bg-teachhq-soft px-4 py-2 text-sm font-semibold text-teachhq-dark opacity-70 focus:outline-none focus:ring-2 focus:ring-teachhq focus:ring-offset-2"
                        title="Sign-in-as impersonation is the next build">
                    <svg class="h-icon w-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                    View as this tenant <span class="text-micro font-normal opacity-80">(coming next)</span>
                </button>
            </div>
        </div>

        <div class="flex flex-col gap-5">
            <!-- Overview -->
            <section id="overview" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                <h2 class="text-lg font-black text-slatecard">Overview</h2>
                <p class="mt-1 text-caption text-ink-soft">The tenant's core record in the estate.</p>
                <dl class="mt-5 grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3">
                    @php
                        $facts = [
                            ['t' => 'Type', 'v' => $tenant['type_label']],
                            ['t' => 'Model', 'v' => $tenant['model_label']],
                            ['t' => 'Slug', 'v' => '/'.$tenant['slug']],
                            ['t' => 'Location', 'v' => $tenant['location'] ?? '—'],
                            ['t' => 'Users', 'v' => (string) $tenant['user_count']],
                            ['t' => 'Added', 'v' => $tenant['created_label']],
                        ];
                        if ($tenant['is_operator']) {
                            $facts[] = ['t' => 'Client orgs', 'v' => (string) $tenant['client_count']];
                            $facts[] = ['t' => 'Client layer', 'v' => $tenant['has_client_layer'] ? 'Yes' : 'No'];
                        }
                    @endphp
                    @foreach ($facts as $f)
                        <div>
                            <dt class="text-mini font-semibold uppercase tracking-wide text-ink-soft">{{ $f['t'] }}</dt>
                            <dd class="mt-1 text-sm font-semibold text-slatecard">{{ $f['v'] }}</dd>
                        </div>
                    @endforeach
                    @if ($tenant['parent'])
                        <div>
                            <dt class="text-mini font-semibold uppercase tracking-wide text-ink-soft">Parent</dt>
                            <dd class="mt-1 text-sm font-semibold">
                                @if ($tenant['parent']['is_platform'])
                                    <span class="text-slatecard">{{ $tenant['parent']['name'] }} (platform)</span>
                                @else
                                    <a href="{{ route('platform.tenants.show', $tenant['parent']['id']) }}" class="text-teachhq transition hover:text-teachhq-dark focus:outline-none focus-visible:ring-2 focus-visible:ring-teachhq">{{ $tenant['parent']['name'] }}</a>
                                @endif
                            </dd>
                        </div>
                    @endif
                </dl>
            </section>

            <!-- Branding -->
            <section id="branding" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                <h2 class="text-lg font-black text-slatecard">Branding &amp; brand kit</h2>
                <p class="mt-1 text-caption text-ink-soft">Styling is driven by the Supabase design-token system; this tenant's brand kit overrides the themeable tokens.</p>
                @if (! empty($tenant['brand_swatches']))
                    <div class="mt-5 flex flex-wrap gap-3">
                        @foreach ($tenant['brand_swatches'] as $sw)
                            <div class="flex items-center gap-2.5 rounded-control border border-line bg-paper px-3 py-2">
                                <span class="h-6 w-6 flex-none rounded-full border border-line" style="background-color: {{ $sw['value'] }}"></span>
                                <span class="text-mini">
                                    <span class="block font-semibold text-slatecard">{{ $sw['label'] }}</span>
                                    <span class="block font-mono text-ink-soft">{{ $sw['value'] }}</span>
                                </span>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="mt-5 rounded-control border border-dashed border-line bg-paper p-5 text-sm text-ink-soft">
                        No custom brand kit values yet — this tenant currently inherits the platform default design tokens. The brand-kit editor (logo, colours, typography over the themeable tokens) is on the roadmap.
                    </div>
                @endif
            </section>

            <!-- Domain & routing -->
            <section id="domain" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                <h2 class="text-lg font-black text-slatecard">Domain &amp; routing</h2>
                <p class="mt-1 text-caption text-ink-soft">How learners reach this tenant's instance.</p>
                <dl class="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
                    @if ($tenant['is_operator'])
                        <div>
                            <dt class="text-mini font-semibold uppercase tracking-wide text-ink-soft">Branded subdomain</dt>
                            <dd class="mt-1 text-sm font-semibold text-slatecard">{{ $tenant['subdomain'] ?? '—' }}</dd>
                        </div>
                    @endif
                    <div>
                        <dt class="text-mini font-semibold uppercase tracking-wide text-ink-soft">Workspace path</dt>
                        <dd class="mt-1 text-sm font-semibold text-slatecard">{{ $tenant['workspace_path'] ?? '—' }}</dd>
                    </div>
                    @if (! $tenant['is_operator'] && $tenant['parent'])
                        <div>
                            <dt class="text-mini font-semibold uppercase tracking-wide text-ink-soft">Served under</dt>
                            <dd class="mt-1 text-sm font-semibold text-slatecard">{{ $tenant['parent']['name'] }} (/{{ $tenant['parent']['slug'] }})</dd>
                        </div>
                    @endif
                    <div>
                        <dt class="text-mini font-semibold uppercase tracking-wide text-ink-soft">Custom domain</dt>
                        <dd class="mt-1 text-sm text-ink-soft">Not configured</dd>
                    </div>
                </dl>
            </section>

            <!-- Clients / parent -->
            <section id="clients" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                @if ($tenant['is_operator'])
                    <h2 class="text-lg font-black text-slatecard">Client organisations</h2>
                    <p class="mt-1 text-caption text-ink-soft">Organisations this operator delivers to.</p>
                    @if (! $tenant['has_client_layer'])
                        <div class="mt-5 rounded-control border border-dashed border-line bg-paper p-5 text-sm text-ink-soft">
                            This tenant runs in-house training — no client layer.
                        </div>
                    @elseif (empty($tenant['clients']))
                        <div class="mt-5 rounded-control border border-dashed border-line bg-paper p-5 text-sm text-ink-soft">
                            No client organisations yet.
                        </div>
                    @else
                        <ul class="mt-5 divide-y divide-line">
                            @foreach ($tenant['clients'] as $client)
                                <li>
                                    <a href="{{ route('platform.tenants.show', $client['id']) }}"
                                       class="flex flex-wrap items-center justify-between gap-2 py-3 transition hover:bg-paper focus:outline-none focus-visible:ring-2 focus-visible:ring-teachhq">
                                        <span class="min-w-0">
                                            <span class="block font-semibold text-slatecard">{{ $client['name'] }}</span>
                                            <span class="block text-mini text-ink-soft">{{ $client['model_label'] }}@if ($client['location']) &middot; {{ $client['location'] }}@endif</span>
                                        </span>
                                        <span class="text-mini font-semibold text-ink-soft">{{ $client['user_count'] }} {{ $client['user_count'] === 1 ? 'user' : 'users' }}</span>
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                @else
                    <h2 class="text-lg font-black text-slatecard">Parent operator</h2>
                    <p class="mt-1 text-caption text-ink-soft">This client organisation is delivered by an operator tenant.</p>
                    @if ($tenant['parent'])
                        <a href="{{ route('platform.tenants.show', $tenant['parent']['id']) }}"
                           class="mt-5 inline-flex items-center gap-2 rounded-control border border-line bg-paper px-4 py-3 text-sm font-semibold text-slatecard transition hover:text-teachhq focus:outline-none focus-visible:ring-2 focus-visible:ring-teachhq">
                            {{ $tenant['parent']['name'] }}
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                    @else
                        <p class="mt-5 text-sm text-ink-soft">No parent operator on record.</p>
                    @endif
                @endif
            </section>

            <!-- Users & roles -->
            <section id="users" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                <h2 class="text-lg font-black text-slatecard">Users &amp; roles</h2>
                <p class="mt-1 text-caption text-ink-soft">People in this tenant.</p>
                <div class="mt-5 flex items-baseline gap-2">
                    <span class="text-3xl font-black tabular-nums text-slatecard">{{ $tenant['user_count'] }}</span>
                    <span class="text-sm text-ink-soft">{{ $tenant['user_count'] === 1 ? 'user' : 'users' }} in this organisation</span>
                </div>
                <p class="mt-3 text-caption text-ink-soft">Per-user administration (invites, roles, teams) is managed in the tenant's own Admin area under Supabase RLS, and will surface here as the impersonation and user-management views land.</p>
            </section>

            <!-- Courses -->
            <section id="courses" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                <h2 class="text-lg font-black text-slatecard">Courses</h2>
                <p class="mt-1 text-caption text-ink-soft">Course catalogue and visibility.</p>
                <div class="mt-5 rounded-control border border-dashed border-line bg-paper p-5 text-sm text-ink-soft">
                    Platform courses cascade to tenants from the Global Course Catalogue. Per-tenant course visibility and tenant-owned courses are on the roadmap.
                </div>
            </section>

            <!-- AI & integrations -->
            <section id="ai" class="scroll-mt-24 rounded-panel border border-line bg-surface p-6 shadow-panel">
                <h2 class="text-lg font-black text-slatecard">AI &amp; integrations</h2>
                <p class="mt-1 text-caption text-ink-soft">Claude (Anthropic) integration.</p>
                <div class="mt-5 rounded-control border border-dashed border-line bg-paper p-5 text-sm text-ink-soft">
                    The AI integration is configured once at the platform-owner level and inherited by every tenant — it is not configured per tenant.
                </div>
            </section>
        </div>
    </main>
</div>
@endsection
